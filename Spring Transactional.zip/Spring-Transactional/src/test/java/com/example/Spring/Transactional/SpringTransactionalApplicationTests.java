package com.example.Spring.Transactional;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringTransactionalApplicationTests {

	@Test
	void contextLoads() {
	}

}
